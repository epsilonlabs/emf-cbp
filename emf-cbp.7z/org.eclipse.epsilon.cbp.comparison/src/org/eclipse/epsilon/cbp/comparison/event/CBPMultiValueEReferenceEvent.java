package org.eclipse.epsilon.cbp.comparison.event;

public class CBPMultiValueEReferenceEvent extends CBPEReferenceEvent {

}
