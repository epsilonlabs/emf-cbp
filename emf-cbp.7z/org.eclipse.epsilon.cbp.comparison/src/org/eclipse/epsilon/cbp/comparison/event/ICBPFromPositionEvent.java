package org.eclipse.epsilon.cbp.comparison.event;

public interface ICBPFromPositionEvent {

	int getFromPosition();

	void setFromPosition(int position);

}
