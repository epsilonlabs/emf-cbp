package org.eclipse.epsilon.cbp.comparison.event;

public class CBPSingleValueEReferenceEvent extends CBPEReferenceEvent {

}
