package org.eclipse.epsilon.cbp.comparison.event;

public class CBPSingleValueEAttributeEvent extends CBPEAttributeEvent {

}
