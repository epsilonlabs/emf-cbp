package org.eclipse.epsilon.cbp.comparison.emfcompare;

public class CBPComparisonUtil {
	
	public final static Object EMPTY_OBJECT = new Object();
}
