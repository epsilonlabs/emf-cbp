package org.eclipse.epsilon.cbp.history;

import org.eclipse.emf.ecore.EObject;

public class AttributeHistory extends ObjectHistory {

	public AttributeHistory(EObject eObject) {
		super(eObject);
		// TODO Auto-generated constructor stub
	}

}
