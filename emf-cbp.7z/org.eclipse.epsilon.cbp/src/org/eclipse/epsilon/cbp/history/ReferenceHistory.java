package org.eclipse.epsilon.cbp.history;

import org.eclipse.emf.ecore.EObject;

public class ReferenceHistory extends ObjectHistory {

	public ReferenceHistory(EObject eObject) {
		super(eObject);
	}

}
