package org.eclipse.epsilon.cbp.event;

import org.eclipse.emf.ecore.EObject;

public abstract class EObjectEvent extends ChangeEvent<EObject> {

}
