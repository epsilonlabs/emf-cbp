package org.eclipse.epsilon.cbp.event;

public interface FromPositionEvent {

	int getFromPosition();

	void setFromPosition(int position);

}
