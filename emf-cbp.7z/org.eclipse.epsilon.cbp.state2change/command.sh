sudo ./Git2CBPConsole PREFIX="LINUX" GIT_DIR="org.eclipse.bpmn2" PRJ_DIR="projects" XMI_DIR="xmi" CBP_DIR="cbp" DIFF_DIR="diff" DEL_PRJ="Y" DEL_XMI="Y"

./Git2CBPConsole PREFIX="EMF" GIT_DIR="/var/tmp/ary506/org.eclipse.emf" PRJ_DIR="/var/tmp/ary506/emf/projects" XMI_DIR="/var/tmp/ary506/emf/xmi" CBP_DIR="/var/tmp/ary506/emf/cbp" DIFF_DIR="diff" DEL_PRJ="Y" DEL_XMI="Y"
./Git2CBPConsole PREFIX="EMFCOMPARE" GIT_DIR="/var/tmp/ary506/org.eclipse.emf.compare" PRJ_DIR="/var/tmp/ary506/emfcompare/projects" XMI_DIR="/var/tmp/ary506/emfcompare/xmi" CBP_DIR="/var/tmp/ary506/emfcompare/cbp" DIFF_DIR="diff" DEL_PRJ="Y" DEL_XMI="Y"
./Git2CBPConsole PREFIX="UML2" GIT_DIR="/var/tmp/ary506/org.eclipse.uml2" PRJ_DIR="/var/tmp/ary506/uml2/projects" XMI_DIR="/var/tmp/ary506/uml2/xmi" CBP_DIR="/var/tmp/ary506/uml2/cbp" DIFF_DIR="diff" DEL_PRJ="Y" DEL_XMI="Y"
./Git2CBPConsole PREFIX="EPSILON" GIT_DIR="/var/tmp/ary506/org.eclipse.epsilon" PRJ_DIR="/var/tmp/ary506/epsilon/projects" XMI_DIR="/var/tmp/ary506/epsilon/xmi" CBP_DIR="/var/tmp/ary506/epsilon/cbp" DIFF_DIR="diff" DEL_PRJ="Y" DEL_XMI="Y"
./Git2CBPConsole PREFIX="MODISCO" GIT_DIR="/var/tmp/ary506/org.eclipse.modisco" PRJ_DIR="/var/tmp/ary506/modisco/projects" XMI_DIR="/var/tmp/ary506/modisco/xmi" CBP_DIR="/var/tmp/ary506/modisco/cbp" DIFF_DIR="diff" DEL_PRJ="Y" DEL_XMI="Y"


ps -u ary506 -L -o pid,tid,psr,pcpu,comm



