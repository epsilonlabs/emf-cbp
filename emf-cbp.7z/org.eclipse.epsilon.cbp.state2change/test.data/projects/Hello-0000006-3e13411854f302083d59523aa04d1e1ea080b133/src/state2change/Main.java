package state2change;

public class Main {

	public static void main(String[] args) {
		Main.greet();
	}

	public static void greet(){
		System.out.println("Hello World!");
	}
}
