package state2change;

public class Main {

	public static void main(String[] args) {
		Main.greet("Vladimir");
	}

	public static void greet(String name){
		System.out.println("Hello " + name + "!");
	}
}
