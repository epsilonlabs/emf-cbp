package state2change;

public class Student extends Person {

	private String studentId;
	
	public Student(String name) {
		super(name);
		// TODO Auto-generated constructor stub
	}

}
