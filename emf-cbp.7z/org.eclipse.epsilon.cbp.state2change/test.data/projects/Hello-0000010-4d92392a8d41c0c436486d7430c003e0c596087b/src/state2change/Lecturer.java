package state2change;

public class Lecturer extends Person {

	private String title;
	
	public Lecturer(String name) {
		super(name);
		// TODO Auto-generated constructor stub
	}

}
