package state2change;

public class Greet {

	public void hello(String name){
		System.out.println("Hello " + name + "!");
	}
}
