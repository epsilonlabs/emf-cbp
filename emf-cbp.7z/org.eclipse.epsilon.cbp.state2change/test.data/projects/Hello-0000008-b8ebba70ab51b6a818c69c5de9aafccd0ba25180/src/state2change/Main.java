package state2change;

public class Main {

	public static void main(String[] args) {
		
		Greet greet = new Greet();
		greet.hello("Vladimir");
	}

	
}
